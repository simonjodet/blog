Elusive-Iconfont
================

The Elusive Iconfont is an icons webfont, optimized for use with twitter's bootstrap.

For examples & usage see http://aristath.github.com/elusive-iconfont/

Licence: [SIL](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
